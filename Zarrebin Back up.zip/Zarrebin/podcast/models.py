from email import message
from django.db import models

# Create your models here.
class Podcaster(models.Model):
    personId = models.IntegerField(verbose_name='شماره')
    firstName = models.CharField(max_length=25, verbose_name='نام');
    lastName = models.CharField(max_length=25,verbose_name='نام خانوادگی');
    position = models.CharField(max_length=25,verbose_name='مسئولیت');
    about = models.TextField(verbose_name='درباره ی من');
    pic = models.ImageField(verbose_name='تصویر')
    def __str__(self) -> str:
        return self.firstName;


class Podcast(models.Model):
    podcastID = models.IntegerField(verbose_name='شماره آرشیو');
    description = models.TextField(verbose_name='درباره‌ی اپیزود');
    highlights = models.TextField(verbose_name='جان مایه');
    name = models.CharField(max_length=25, verbose_name='نام');
    episodeNum = models.IntegerField(verbose_name='شماره ی اپیزود');
    producer = models.ForeignKey (Podcaster, on_delete=models.SET_NULL, null=True, verbose_name='تهیه کننده');
    cast = models.TextField(verbose_name='عوامل');
    publishDate=models.DateField(verbose_name='تاریخ');
    music = models.TextField(verbose_name='موسیقی ها');
    pic = models.ImageField(verbose_name='تصویر')
    text = models.TextField(verbose_name='متن', null=True)
    

    def __str__(self) -> str:
        return self.name;

class Message(models.Model):
    sender = models.CharField(max_length=25, verbose_name='ارسال کننده');
    subject = models.CharField(max_length=50, verbose_name='موضوع');
    message = models.TextField(verbose_name='پیام');

 