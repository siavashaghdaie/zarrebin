from django.urls import path
from . import views

urlpatterns = [
    
    path('', views.index, name='index'),
    #path('me/<str:pk>', views.me, name='me'),
    path('main/', views.main, name='main'),
    path('archive/', views.archive, name='archive'),
    path('podcasters/', views.podcasters, name='podcasters'),
]