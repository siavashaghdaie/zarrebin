from email import contentmanager
from importlib.metadata import requires
from django.shortcuts import redirect, render
from .models import Podcaster,Podcast,Message;
from .forms import MessageForm

# Create your views here.
def index(request):
    form = MessageForm()
    if request.method == "POST":
        form = MessageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')

    messages = Message.objects.all()
    context = {'form':form, 'messages':messages}
    return render(request, 'podcast/index.html',context)


def me(request, pk):
    message = Message.objects.get(id=pk)
    form = MessageForm(instance=message)
    if request.method == "POST":
        form = MessageForm(request.POST, instance=message)
        if form.is_valid():
            form.save()
            #return redirect('index')

    messages = Message.objects.all()
    context = {'form':form, 'messages':messages}
    return render(request, 'podcast/index.html',context)


def main(request):
    form = MessageForm()
    if request.method == "POST":
        form = MessageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')

    messages = Message.objects.all()
    context = {'form':form, 'messages':messages}
    return render(request, 'podcast/main.html')

def podcasters(request):
    podcaster = Podcaster.objects.all()
    context = {'podcaster': podcaster}
    return render(request, 'podcast/podcasters.html', context)


def archive(request):
    context={}
    return render (request, 'podcast/archive.html', context)
