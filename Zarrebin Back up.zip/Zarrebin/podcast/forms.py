
from django.forms import ModelForm, widgets
from django import forms
from .models import Message

class MessageForm(ModelForm):
    #Required_css_class = 'form-fields'
    class Meta:
        model = Message
        fields = '__all__'
        #widgets={
            #'sender' : forms.TextInput(attrs={'id':'send-box'})
        #}
       